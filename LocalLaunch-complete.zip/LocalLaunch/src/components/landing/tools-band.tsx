import Link from "next/link";
import { Container } from "@/components/container";
import { TOOLS } from "@/lib/tools";

export function ToolsBand() {
  return (
    <section id="tools" aria-labelledby="tools-heading" className="bg-[#f4f3ef] py-16 sm:py-24">
      <Container>
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#4d5c57]">
              The house toolkit
            </p>
            <h2
              id="tools-heading"
              className="font-display mt-3 text-3xl font-medium tracking-tight text-stone-900 sm:text-5xl"
            >
              Twenty-two rooms. One set of facts.
            </h2>
            <p className="mt-4 text-base leading-7 text-stone-600">
              Start with Facebook if that is your main channel, or open House
              Operations for SEO and ads. The assistant and the other tools reuse
              the same details, kept only in this browser tab.
            </p>
          </div>
          <Link
            href="/tools"
            className="text-sm font-semibold text-[#4d5c57] hover:text-[#191919] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1e3a34]"
          >
            View the full toolkit
          </Link>
        </div>
        <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {TOOLS.map((tool) => (
            <li key={tool.slug}>
              <Link
                href={`/tools/${tool.slug}`}
                className="paper-card flex h-full flex-col rounded-sm border border-stone-200 p-5 transition hover:-translate-y-0.5 hover:border-[#1e3a34] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1e3a34]"
              >
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#4d5c57]">
                  {tool.category}
                </p>
                <h3 className="mt-2 font-display text-xl text-stone-900">{tool.name}</h3>
                <p className="mt-2 flex-1 text-sm leading-6 text-stone-600">{tool.tagline}</p>
                <p className="mt-4 text-sm font-semibold text-[#191919]">Open</p>
              </Link>
            </li>
          ))}
        </ul>
      </Container>
    </section>
  );
}
